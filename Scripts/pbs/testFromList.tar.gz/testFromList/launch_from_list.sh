#!/bin/bash

#path to your executable 
exePATH="$PWD";

#list of file you want to analyze 
LISTDIR="$PWD/lists"

#output and error folders 
OUTDIR="$PWD/out"
ERRDIR="$PWD/err"

#queue selected to run the jobs 
QUEUE="compass"

#place where to write the results 
RESDIR="$PWD/results" 

#User plugin to be used 
USER="ToolboxExample" 

#Executable to be used 
EXE="toolbox"

#TEST variable 
#TEST=TRUE

i=0
rm -rf $OUTDIR $ERRDIR
mkdir $OUTDIR $ERRDIR

for run in `cat $LISTDIR/list`
  do
  i=$((i+1))
  JOBNAME="TEST_FROM_LIST_${i}"
  if [ "${TEST}" == "TRUE" ] ; then
  echo "qsub -q $QUEUE -N $JOBNAME -o $OUTDIR/${JOBNAME}.out -e $ERRDIR/${JOBNAME}.err $exePATH/$EXE -u $USER -h $RESDIR/${JOBNAME}.root $run"  
  else 
  qsub -q $QUEUE -N $JOBNAME -o $OUTDIR/${JOBNAME}.out -e $ERRDIR/${JOBNAME}.err $exePATH/$EXE -u $USER -h $RESDIR/${JOBNAME}.root $run  
  fi 
 done
